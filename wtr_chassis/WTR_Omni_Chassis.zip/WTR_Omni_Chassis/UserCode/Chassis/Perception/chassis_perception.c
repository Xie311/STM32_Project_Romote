#include "chassis_perception.h"

/**
 * @brief   码盘定位系统初始化
 */

void Chassis_Perception_Init(void)
{
    HAL_UART_Receive_DMA(&OPS_UART_HANDLE, ops_buffer, 28);
    __HAL_UART_ENABLE_IT(&OPS_UART_HANDLE, UART_IT_IDLE);
}

/**
 * @brief   码盘定位系统调试
 */
void Perception_Debug_Task(void)
{
    for (;;) {HAL_UART_Transmit(&huart7, &(OPS_Data.pos_x), sizeof(OPS_Data), 0xff);}
    printf("1:%f", OPS_Data.pos_x);
    osDelay(100);
}
