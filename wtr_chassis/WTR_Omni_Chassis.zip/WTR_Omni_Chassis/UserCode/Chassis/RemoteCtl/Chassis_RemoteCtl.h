/*
 * @Author: Chen Yitong
 * @Date: 2023-09-23 13:47:36
 * @LastEditors: Chen Yitong
 * @LastEditTime: 2023-09-23 20:03:25
 * @FilePath: \WTR_Chassis\麦克纳姆轮\UserCode\Chassis\RemoteCtl\Chassis_RemoteCtl.h
 * @Brief:
 *
 * Copyright (c) 2023 by ChenYiTong, All Rights Reserved.
 */

#ifndef __CHASSIS_REMOTECTL_H__
#define __CHASSIS_REMOTECTL_H__

#include "Chassis_Start.h"
void Chassis_RemoteCtl_Init();

#endif // __CHASSIS_REMOTECTL_H__