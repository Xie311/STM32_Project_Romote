#ifndef __CHASSIS_DEBUG_H
#define __CHASSIS_DEBUG_H

#include "chassis_start.h"

void Debug_TaskStart(void);
void Debug_Task(void *argument);

#endif